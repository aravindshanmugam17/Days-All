import Form from './Pages/Form';

function App() {
  return (
    <div>
      <Form />
    </div>
  );
}

export default App;
